using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour
{

    [SerializeField] GameObject EnemyPrefab;
    float SpawnCoolDown = 0.5f;
    float SpawnTimer = 0.0f;
    float MaxX;
    float MinX;
    float Y;

    // Start is called before the first frame update
    void Start()
    {
        MaxX = GameObject.Find("MaxBorder").transform.position.x;
        MinX = GameObject.Find("MinBorder").transform.position.x;
        Y = GameObject.Find("MinBorder").transform.position.y;
    }

    void SpawnEnemy()
    {
        if (SpawnTimer > SpawnCoolDown)
        {
            var NewEnemy = Instantiate(EnemyPrefab,transform);
            float X = Random.Range(MinX, MaxX);
            
            NewEnemy.transform.position = new Vector3(X, Y, 0.0f);
            SpawnTimer = 0.0f;
        }
        SpawnTimer += Time.deltaTime;
    }

    // Update is called once per frame
    void Update()
    {
        SpawnEnemy();
    }
}
