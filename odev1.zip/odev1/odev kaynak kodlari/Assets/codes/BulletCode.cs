using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletCode : MonoBehaviour
{

    //[SerializeField] float Speed = 10.0f;
    Vector3 SpeedVector;
    // Start is called before the first frame update
    void Start()
    {
        SpeedVector.y = 20;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("CanKilled")) //Dusman tagi �CanKilled� ise mermi ona carpinca ikisi yok olur
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)//mermi sahnenin ust sinirina carptigi zaman mermi yok et
    {
        if (collision.name == "sceneTopBoard")
        {
            Destroy(gameObject);
        } 
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += SpeedVector * Time.deltaTime;
    }
}
