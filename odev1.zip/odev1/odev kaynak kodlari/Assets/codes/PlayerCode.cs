using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCode : MonoBehaviour
{
    Vector3 SpeedVector; //hiz vectoru
    public float Speed; //arayuzden ayarlanabilir hiz
    public BoxCollider2D BoxCollider; //oyuncunun sinirlari 
    [SerializeField] GameObject BulletPrefab; //mermi sablonunu editordan seciyoruz
    Transform SquareTransform;
    float BulletCoolDown = 0.2f;
    float Bullettimer = 0.0f;
    float xMove;
    float yMove;
    Rigidbody2D rb;
    List<GameObject> Bullets;
    // Start is called before the first frame update
    void Start()
    {
        SpeedVector.x = Speed; //hiz atama

        SquareTransform = GameObject.Find("BulletSpawn").transform;  //mermi cikis noktasi kordinati buluyoruz

        Bullets = new List<GameObject>(); //atilan mermileri tutacak listeyi olusturduk

        rb = GetComponent<Rigidbody2D>(); //rigidbodyi cekiyoruz
    }

    void inputControl() //giris kontrolleri fonksiyonu(basilan tusa gore islev yapilmasi)
    {
        xMove = Input.GetAxis("Horizontal"); 
        yMove = Input.GetAxis("Vertical");
    }

    void positionUpdate() //hareket ettirme fonksiyonu
    {
        SpeedVector.x = xMove * Speed; //tusa basili tuttukca hiz artar
        SpeedVector.y = yMove * Speed;

        rb.velocity = SpeedVector; //hizi rigidbodye ekleyerek harekti sagliyoruz

    }
    void fireControl()
    {
        if (Input.GetKey(KeyCode.Space))  //space tusuna baslinca karekterin mermi atmasini sagladik 
        {
            if (Bullettimer >= BulletCoolDown) //mermiye cooldown ekledik (belirli bir sure gecmeden ard arda mermi atamiyoruz)
            {
                var NewBullet = Instantiate(BulletPrefab);
                NewBullet.transform.position = SquareTransform.position;
                Bullets.Add(NewBullet); //butun mermilerin referanslarini bir listeye attik
                Bullettimer = 0.0f;
            }
        }
        Bullettimer += Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D collision)  //dusman bizim oyuncu nesnesine carptigi zaman yok olmasini saglayan fonksiyon
    {
        if (collision.CompareTag("CanKilled"))
        {
            Destroy(collision.gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        inputControl();
        positionUpdate();
        fireControl();
    }
}
