using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCode : MonoBehaviour
{
    //[SerializeField] float Speed = 10.0f;
    Rigidbody2D rb;
    Vector3 SpeedVector;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        SpeedVector.y = -5;
        float X = Random.Range(15 , -15);
        SpeedVector.x = X;
        rb.velocity = SpeedVector;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name == "sceneRightBoard") //dusman sag tarafa carptigi zaman diger tarafa dogru hiz kanarak yonunu degistirir
        {
            SpeedVector.x = -5;
            rb.velocity = SpeedVector;

        }
        if (collision.name == "sceneLeftBoard")//dusman sol tarafa carptigi zaman diger tarafa dogru hiz kanarak yonunu degistirir
        {
            SpeedVector.x = 5;
            rb.velocity = SpeedVector;

        }

    }

    private void OnTriggerExit2D(Collider2D collision) //dusman sahnenin alt sinirina carptigi zaman dusmani yok et
    {
        if (collision.name == "sceneDownBoard")
        {
            Destroy(gameObject);
        } 
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
